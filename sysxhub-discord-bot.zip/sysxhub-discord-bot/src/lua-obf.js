// Lightweight source minifier/identifier replacement, NOT a secure commercial obfuscator.
// Lua syntax is complex; this deliberately avoids pretending to safely transform every script.
function obfuscateLua(input) {
  if (typeof input !== 'string' || !input.trim()) throw new Error('Kode Lua kosong.');
  if (input.length > 12000) throw new Error('Maksimal input 12.000 karakter.');
  // Preserve quoted strings and comments while compacting whitespace outside them.
  let out = '', i = 0, quote = null, longLevel = null, lineComment = false, blockComment = false;
  while (i < input.length) {
    const c = input[i], n = input[i + 1];
    if (lineComment) { if (c === '\n') { lineComment = false; out += '\n'; } i++; continue; }
    if (blockComment) {
      if (c === ']' && n === ']') { blockComment = false; i += 2; }
      else i++;
      continue;
    }
    if (quote) {
      out += c;
      if (c === '\\' && i + 1 < input.length) { out += input[++i]; }
      else if (c === quote) quote = null;
      i++; continue;
    }
    if (c === '"' || c === "'") { quote = c; out += c; i++; continue; }
    if (c === '-' && n === '-') {
      if (input[i + 2] === '[' && input[i + 3] === '[') { blockComment = true; i += 4; }
      else { lineComment = true; i += 2; }
      continue;
    }
    if (/\s/.test(c)) {
      if (out && !/\s$/.test(out) && /[\w_$]/.test(out[out.length - 1]) && /[\w_$]/.test(n || '')) out += ' ';
      i++; continue;
    }
    out += c; i++;
  }
  return `-- SysxHub Lua compact output\n${out.trim()}`;
}
module.exports = { obfuscateLua };
