const fs = require('node:fs');
const path = require('node:path');
const FILE = path.join(__dirname, '..', 'data.json');

function read() {
  try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); }
  catch { return { scripts: [], orders: [], keys: [], tickets: [] }; }
}
function write(data) {
  fs.writeFileSync(FILE, JSON.stringify(data, null, 2), 'utf8');
}
function addScript(script) {
  const data = read();
  const entry = { id: `S${Date.now().toString(36).toUpperCase()}`, createdAt: new Date().toISOString(), ...script };
  data.scripts.push(entry); write(data); return entry;
}
function listScripts(category) {
  const scripts = read().scripts;
  return category ? scripts.filter(s => s.category.toLowerCase() === category.toLowerCase()) : scripts;
}
function getScript(id) { return read().scripts.find(s => s.id.toLowerCase() === String(id).toLowerCase()); }
function deleteScript(id) {
  const data = read(); const before = data.scripts.length;
  data.scripts = data.scripts.filter(s => s.id.toLowerCase() !== String(id).toLowerCase());
  write(data); return data.scripts.length !== before;
}
function addOrder(order) {
  const data = read(); const entry = { id: `O${Date.now().toString(36).toUpperCase()}`, status: 'pending', createdAt: new Date().toISOString(), ...order };
  data.orders.push(entry); write(data); return entry;
}
function updateOrder(id, status, reviewedBy) {
  const data = read(); const order = data.orders.find(o => o.id === id);
  if (!order || order.status !== 'pending') return null;
  order.status = status; order.reviewedBy = reviewedBy; order.reviewedAt = new Date().toISOString(); write(data); return order;
}
function addTicket(ticket) { const data = read(); data.tickets.push(ticket); write(data); }
module.exports = { addScript, listScripts, getScript, deleteScript, addOrder, updateOrder, addTicket };
