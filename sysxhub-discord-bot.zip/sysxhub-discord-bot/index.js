require('dotenv').config();
const {
  Client, GatewayIntentBits, Partials, Events, EmbedBuilder, ActionRowBuilder,
  ButtonBuilder, ButtonStyle, StringSelectMenuBuilder, PermissionFlagsBits,
  ChannelType, AttachmentBuilder
} = require('discord.js');
const QRCode = require('qrcode');
const { obfuscateLua } = require('./src/lua-obf');
const store = require('./src/storage');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMembers, GatewayIntentBits.GuildModeration, GatewayIntentBits.GuildMessages], partials: [Partials.Channel] });
const OWNER_ID = process.env.OWNER_ID || '1480748275324686336';
const WEBSITE = 'https://sysxhub.netlify.app/';
const QRIS = '00020101021126570011ID.DANA.WWW011893600915380408222102098040822210303UMI51440014ID.CO.QRIS.WWW0215ID10243638039570303UMI5204541153033605802ID5920Toko kelontong Mamat6011Kota Bekasi61051713463048332';
const PACKAGES = {
  trial: { label: 'Trial', duration: '1 hari', price: 0 },
  basic: { label: 'Basic', duration: '3 hari', price: 5000 },
  weekly: { label: 'Weekly', duration: '7 hari', price: 10000 },
  monthly: { label: 'Monthly', duration: '30 hari', price: 20000 },
  permanent: { label: 'Permanent', duration: 'Permanen', price: null },
  lifetime: { label: 'Lifetime + Update', duration: 'Lifetime', price: null }
};
const money = n => n === 0 ? 'Gratis' : n == null ? 'Hubungi owner untuk harga final' : `Rp${n.toLocaleString('id-ID')}`;
const isOwner = id => id === OWNER_ID;
const makeEmbed = (title, description) => new EmbedBuilder().setColor(0x5865F2).setTitle(title).setDescription(description).setFooter({ text: 'SysxHub • Indonesian / English' }).setTimestamp();
async function sendPanel(channelId, embed, components = []) {
  if (!channelId) return 'skip';
  const channel = await client.channels.fetch(channelId).catch(() => null);
  if (!channel || !channel.isTextBased()) return 'missing';
  const recent = await channel.messages.fetch({ limit: 15 }).catch(() => null);
  if (recent?.some(m => m.author.id === client.user.id && m.embeds.some(e => e.footer?.text?.startsWith('SYSXHUB_PANEL:')) && m.embeds[0].footer.text === `SYSXHUB_PANEL:${embed.data.title}`)) return 'exists';
  embed.setFooter({ text: `SYSXHUB_PANEL:${embed.data.title}` });
  await channel.send({ embeds: [embed], components });
  return 'sent';
}
function ticketPanel() {
  return [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket_create').setLabel('Buat Tiket / Create Ticket').setStyle(ButtonStyle.Primary).setEmoji('🎫'))];
}
function buyPanel() {
  const menu = new StringSelectMenuBuilder().setCustomId('buy_package').setPlaceholder('Pilih paket / Choose a package').addOptions(Object.entries(PACKAGES).map(([value,p])=>({ label: p.label, value, description: `${p.duration} • ${money(p.price)}`.slice(0,100) })));
  return [new ActionRowBuilder().addComponents(menu)];
}
function verifyPanel() {
  return [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('verify_member').setLabel('Verify / Verifikasi').setStyle(ButtonStyle.Success).setEmoji('✅'))];
}
function scriptPanel() {
  return [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('show_scripts').setLabel('Lihat Script / Browse Scripts').setStyle(ButtonStyle.Primary).setEmoji('📜'))];
}
async function setupPanels(guild) {
  const rules = makeEmbed('SysxHub Rules / Peraturan', '**Bahasa Indonesia**\n1. Hormati semua member.\n2. Dilarang spam, scam, doxxing, atau merusak server.\n3. Gunakan channel sesuai topik.\n4. Dilarang menyebarkan malware atau mencuri akun/data.\n5. Ikuti instruksi staff dan gunakan tiket untuk bantuan.\n\n**English**\n1. Respect all members.\n2. No spam, scams, doxxing, or server disruption.\n3. Use channels for their intended topics.\n4. No malware distribution or account/data theft.\n5. Follow staff instructions and use tickets for support.');
  const results = await Promise.all([
    sendPanel(process.env.TICKET_CHANNEL_ID, makeEmbed('Support Ticket / Tiket Bantuan', 'Tekan tombol untuk membuat tiket privat.\nPress the button to open a private support ticket.'), ticketPanel()),
    sendPanel(process.env.BUY_CHANNEL_ID, makeEmbed('SysxHub Buy Panel / Panel Pembelian', Object.values(PACKAGES).map(p=>`**${p.label}** — ${p.duration} — ${money(p.price)}`).join('\n')+'\n\nPilih paket pada menu di bawah. QRIS statis; masukkan nominal yang diberikan dan tunggu approval owner.\nChoose a package below. Static QRIS; enter the requested amount and wait for owner approval.'), buyPanel()),
    sendPanel(process.env.SCRIPT_CHANNEL_ID, makeEmbed('Script Library / Katalog Script', 'Tekan tombol untuk melihat kategori script yang tersedia.\nPress the button to browse available script categories.'), scriptPanel()),
    sendPanel(process.env.VERIFY_CHANNEL_ID, makeEmbed('Verify Role / Verifikasi Role', 'Tekan Verify untuk mendapatkan role anggota.\nPress Verify to receive the member role.'), verifyPanel()),
    sendPanel(process.env.RULES_CHANNEL_ID, rules, []),
  ]);
  return results;
}
client.once(Events.ClientReady, async c => {
  console.log(`Logged in as ${c.user.tag}`);
  c.user.setActivity(process.env.BOT_STATUS || 'SysxHub | /help');
  // Panels are sent once per channel based on a marker in the recent messages.
  const guild = process.env.GUILD_ID ? await client.guilds.fetch(process.env.GUILD_ID).catch(()=>null) : null;
  if (guild) {
    const result = await setupPanels(guild).catch(e => { console.error('Auto panel setup failed:', e.message); return []; });
    console.log('Auto panels:', result.join(', '));
  }
});
client.on(Events.GuildMemberAdd, async member => {
  const channel = await client.channels.fetch(process.env.WELCOME_CHANNEL_ID).catch(()=>null);
  if (!channel?.isTextBased()) return;
  const embed = makeEmbed('Welcome to SysxHub! / Selamat datang!', `Welcome ${member} to **${member.guild.name}**!\nPlease read the rules and verify your role.\n\nSelamat datang ${member}! Silakan baca peraturan dan lakukan verifikasi.`).setThumbnail(member.user.displayAvatarURL());
  channel.send({ embeds: [embed] }).catch(()=>{});
});
client.on(Events.InteractionCreate, async interaction => {
  try {
    if (interaction.isChatInputCommand()) {
      const { commandName: cmd } = interaction;
      if (cmd === 'ping') return interaction.reply({ content: `Pong! ${client.ws.ping}ms`, ephemeral: true });
      if (cmd === 'help') return interaction.reply({ embeds: [makeEmbed('SysxHub Commands / Daftar Command', '`/obf kode` — compact kode Lua\n`/to user menit alasan` — timeout member\n`/ban user alasan` — ban member\n`/bypass url` — request ke provider bypass yang dikonfigurasi\n`/beli` — pilih paket\n`/addscript nama kategori loadstring` — tambah script\n`/scripts kategori` — lihat katalog\n`/deletescript id` — hapus script\n`/setup` — kirim panel\n\nModerator commands require Discord permissions.')], ephemeral: true });
      if (cmd === 'setup') {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.Administrator)) return interaction.reply({ content: 'Khusus administrator.', ephemeral: true });
        await interaction.deferReply({ ephemeral: true });
        const result = await setupPanels(interaction.guild);
        return interaction.editReply(`Setup panel selesai. Hasil: ${result.join(', ')}. Panel yang sudah ada tidak diduplikasi.`);
      }
      if (cmd === 'obf') {
        const input = interaction.options.getString('kode', true);
        try {
          const output = obfuscateLua(input);
          const attachment = new AttachmentBuilder(Buffer.from(output, 'utf8'), { name: 'sysxhub-obfuscated.lua' });
          return interaction.reply({ content: 'Kode Lua sudah dikompak. Ini bukan obfuscator kriptografis dan tetap harus dites di environment lu.\nLua code compacted; test it in your target environment.', files: [attachment], ephemeral: true });
        } catch(e) { return interaction.reply({ content: e.message, ephemeral: true }); }
      }
      if (cmd === 'to') {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ModerateMembers)) return interaction.reply({ content: 'Butuh permission Moderate Members.', ephemeral: true });
        const user = interaction.options.getUser('user', true), minutes = interaction.options.getInteger('menit', true), reason = interaction.options.getString('alasan') || `Timeout by ${interaction.user.tag}`;
        if (user.id === interaction.user.id) return interaction.reply({ content: 'Kamu tidak bisa timeout diri sendiri.', ephemeral: true });
        const member = await interaction.guild.members.fetch(user.id).catch(()=>null);
        if (!member) return interaction.reply({ content: 'Member tidak ditemukan di server.', ephemeral: true });
        await member.timeout(minutes * 60 * 1000, reason);
        return interaction.reply({ content: `✅ ${user.tag} timeout ${minutes} menit. Alasan: ${reason}`, ephemeral: true });
      }
      if (cmd === 'ban') {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.BanMembers)) return interaction.reply({ content: 'Butuh permission Ban Members.', ephemeral: true });
        const user = interaction.options.getUser('user', true), reason = interaction.options.getString('alasan') || `Banned by ${interaction.user.tag}`;
        if (user.id === interaction.user.id) return interaction.reply({ content: 'Kamu tidak bisa ban diri sendiri.', ephemeral: true });
        await interaction.guild.members.ban(user.id, { reason });
        return interaction.reply({ content: `🔨 ${user.tag} berhasil di-ban. Alasan: ${reason}`, ephemeral: true });
      }
      if (cmd === 'bypass') {
        const target = interaction.options.getString('url', true);
        if (!process.env.BYPASS_API_URL) return interaction.reply({ content: '⚠️ Provider bypass belum dikonfigurasi. Bot tidak akan mengirim key palsu atau mengklaim bypass berhasil. Tambahkan BYPASS_API_URL dari provider yang benar-benar kamu gunakan di .env.', ephemeral: true });
        await interaction.deferReply({ ephemeral: true });
        try {
          const headers = { 'content-type': 'application/json' };
          if (process.env.BYPASS_API_KEY) headers.authorization = `Bearer ${process.env.BYPASS_API_KEY}`;
          const response = await fetch(process.env.BYPASS_API_URL, { method: 'POST', headers, body: JSON.stringify({ url: target, discordUserId: interaction.user.id }) , signal: AbortSignal.timeout(20000) });
          if (!response.ok) throw new Error(`Provider HTTP ${response.status}`);
          const data = await response.json();
          const key = data.key || data.deltaKey || data.result;
          if (!key || data.success === false) throw new Error('Provider tidak mengembalikan key sukses yang valid.');
          const msg = `**Your bypass is ready now!**\n\`\`\`key delta\n${String(key).slice(0,1000)}\n\`\`\`\nCheck my website: ${WEBSITE}\n\n**Bahasa Indonesia**\nBypass kamu siap. Simpan key di atas dan kunjungi website SysxHub.\n\n**English**\nYour bypass is ready. Keep the key above and visit the SysxHub website.`;
          return interaction.editReply({ content: msg });
        } catch(e) { console.error('Bypass provider error:', e.message); return interaction.editReply({ content: '❌ Bypass belum berhasil dipastikan. Provider error/format respons tidak cocok. Coba lagi nanti atau periksa konfigurasi provider.' }); }
      }
      if (cmd === 'beli') return interaction.reply({ embeds: [makeEmbed('Buy / Beli Paket', Object.values(PACKAGES).map(p=>`**${p.label}** — ${p.duration} — ${money(p.price)}`).join('\n')+'\n\nGunakan menu di channel panel buy untuk membuat order.\nUse the buy panel channel to create an order.')], components: buyPanel(), ephemeral: true });
      if (cmd === 'addscript') {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ content: 'Butuh permission Manage Server.', ephemeral: true });
        const script = store.addScript({ name: interaction.options.getString('nama', true), category: interaction.options.getString('kategori', true), code: interaction.options.getString('loadstring', true), authorId: interaction.user.id });
        return interaction.reply({ content: `Script ditambahkan. ID: **${script.id}** • Kategori: **${script.category}**`, ephemeral: true });
      }
      if (cmd === 'scripts') {
        const category = interaction.options.getString('kategori'); const scripts = store.listScripts(category);
        if (!scripts.length) return interaction.reply({ content: 'Belum ada script di kategori itu. Admin bisa menambahkannya dengan /addscript.', ephemeral: true });
        const desc = scripts.slice(0,15).map(s => `**${s.name}** — ${s.category} — ID ${s.id}`).join('\n');
        const row = new ActionRowBuilder().addComponents(new StringSelectMenuBuilder().setCustomId('script_select').setPlaceholder('Pilih script / Choose script').addOptions(scripts.slice(0,25).map(s=>({ label: s.name.slice(0,100), description: `${s.category} • ${s.id}`.slice(0,100), value: s.id }))));
        return interaction.reply({ embeds: [makeEmbed('Script Library / Katalog Script', desc)], components: [row], ephemeral: true });
      }
      if (cmd === 'deletescript') {
        if (!interaction.memberPermissions?.has(PermissionFlagsBits.ManageGuild)) return interaction.reply({ content: 'Butuh permission Manage Server.', ephemeral: true });
        const id = interaction.options.getString('id', true); return interaction.reply({ content: store.deleteScript(id) ? `Script ${id} dihapus.` : `Script ${id} tidak ditemukan.`, ephemeral: true });
      }
      if (cmd === 'key') return interaction.reply({ content: 'Key pembelian saat ini diproses manual oleh owner melalui order. Command validasi key otomatis belum diaktifkan; jangan anggap key valid sebelum dikonfirmasi owner.', ephemeral: true });
      if (cmd === 'revokekey') return interaction.reply({ content: 'Penyimpanan dan validasi key otomatis belum diimplementasikan. Command ini tidak mencabut key apa pun.', ephemeral: true });
    }
    if (interaction.isStringSelectMenu()) {
      if (interaction.customId === 'buy_package') {
        const packageId = interaction.values[0], pack = PACKAGES[packageId];
        const order = store.addOrder({ userId: interaction.user.id, username: interaction.user.tag, packageId, packageLabel: pack.label, price: pack.price });
        const amount = pack.price == null ? 'Hubungi owner untuk harga final sebelum transfer.' : pack.price === 0 ? 'Gratis — tidak perlu pembayaran.' : `Transfer tepat **${money(pack.price)}**.`;
        const qr = await QRCode.toBuffer(QRIS, { type: 'png', width: 420, margin: 2 });
        const attachment = new AttachmentBuilder(qr, { name: 'sysxhub-qris.png' });
        const embed = makeEmbed(`Order ${order.id} / Pesanan ${order.id}`, `Pembeli: ${interaction.user}\nPaket: **${pack.label}**\nDurasi: ${pack.duration}\nHarga: **${money(pack.price)}**\n\n${amount}\nScan QRIS pada gambar. QRIS ini statis; pastikan nominal yang ditransfer benar.\n\n**Indonesia:** Setelah transfer, tunggu owner memeriksa pembayaran. Jangan kirim PIN/OTP.\n**English:** After payment, wait for the owner to verify it. Never share your PIN/OTP.`);
        const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`order_approve:${order.id}`).setLabel('Approve').setStyle(ButtonStyle.Success), new ButtonBuilder().setCustomId(`order_deny:${order.id}`).setLabel('Denied').setStyle(ButtonStyle.Danger));
        const owner = await client.users.fetch(OWNER_ID).catch(()=>null);
        if (owner) await owner.send({ embeds: [embed], files: [attachment], components: [row] }).catch(()=>{});
        return interaction.reply({ embeds: [embed], files: [attachment], ephemeral: true });
      }
      if (interaction.customId === 'script_select') {
        const script = store.getScript(interaction.values[0]);
        if (!script) return interaction.reply({ content: 'Script tidak ditemukan.', ephemeral: true });
        const file = new AttachmentBuilder(Buffer.from(script.code, 'utf8'), { name: `${script.id}.lua` });
        return interaction.reply({ embeds: [makeEmbed(script.name, `Kategori: **${script.category}**\nID: ${script.id}\n\n**Indonesia:** File kode dilampirkan. Pastikan kamu mempercayai sumbernya sebelum menjalankan.\n**English:** Code file attached. Verify the source before running it.`)], files: [file], ephemeral: true });
      }
    }
    if (interaction.isButton()) {
      if (interaction.customId === 'verify_member') {
        const roleId = process.env.VERIFIED_ROLE_ID;
        if (!roleId) return interaction.reply({ content: 'Role verifikasi belum dikonfigurasi. Isi VERIFIED_ROLE_ID di .env.', ephemeral: true });
        const member = await interaction.guild.members.fetch(interaction.user.id);
        await member.roles.add(roleId);
        return interaction.reply({ content: '✅ Berhasil verifikasi! / Verification complete!', ephemeral: true });
      }
      if (interaction.customId === 'ticket_create') {
        const existing = interaction.guild.channels.cache.find(c => c.type === ChannelType.GuildText && c.topic === `sysx-ticket:${interaction.user.id}`);
        if (existing) return interaction.reply({ content: `Tiket kamu sudah ada: ${existing}`, ephemeral: true });
        const safe = interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,18) || 'member';
        const channel = await interaction.guild.channels.create({ name: `ticket-${safe}`, type: ChannelType.GuildText, topic: `sysx-ticket:${interaction.user.id}`, permissionOverwrites: [{ id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] }, { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] }, { id: client.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] }] });
        await channel.send({ content: `${interaction.user}`, embeds: [makeEmbed('Support Ticket / Tiket Bantuan', 'Jelaskan masalah atau kebutuhanmu di sini.\nPlease describe your issue or request here.')], components: [new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId('ticket_close').setLabel('Close Ticket / Tutup Tiket').setStyle(ButtonStyle.Danger))] });
        return interaction.reply({ content: `Tiket dibuat: ${channel}`, ephemeral: true });
      }
      if (interaction.customId === 'ticket_close') {
        const ownerMatch = interaction.channel.topic?.match(/^sysx-ticket:(\d+)$/);
        if (!isOwner(interaction.user.id) && ownerMatch?.[1] !== interaction.user.id && !interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels)) return interaction.reply({ content: 'Kamu tidak boleh menutup tiket ini.', ephemeral: true });
        await interaction.reply({ content: 'Tiket ditutup. Channel akan dihapus dalam beberapa detik.', ephemeral: true });
        setTimeout(()=>interaction.channel.delete().catch(()=>{}), 5000); return;
      }
      if (interaction.customId === 'show_scripts') return interaction.reply({ content: 'Gunakan `/scripts` untuk melihat kategori dan memilih script. / Use `/scripts` to browse scripts.', ephemeral: true });
      if (interaction.customId.startsWith('order_')) {
        if (!isOwner(interaction.user.id)) return interaction.reply({ content: 'Hanya owner yang bisa approve/deny order.', ephemeral: true });
        const [action, orderId] = interaction.customId.split(':');
        const status = action === 'order_approve' ? 'approved' : 'denied';
        const order = store.updateOrder(orderId, status, interaction.user.id);
        if (!order) return interaction.reply({ content: 'Order tidak ditemukan atau sudah diproses.', ephemeral: true });
        await interaction.update({ embeds: [EmbedBuilder.from(interaction.message.embeds[0]).setColor(status === 'approved' ? 0x57F287 : 0xED4245).setFooter({ text: `Order ${orderId} • ${status.toUpperCase()} by ${interaction.user.tag}` })], components: [] });
        const buyer = await client.users.fetch(order.userId).catch(()=>null);
        if (buyer) await buyer.send({ embeds: [makeEmbed(status === 'approved' ? 'Payment Approved / Pembayaran Disetujui' : 'Payment Denied / Pembayaran Ditolak', status === 'approved' ? `Order **${orderId}** disetujui owner.\nOrder **${orderId}** was approved by the owner.\n\nKey/akses harus diberikan secara manual oleh owner.` : `Order **${orderId}** ditolak. Hubungi owner jika ada kesalahan.\nOrder **${orderId}** was denied. Contact the owner if this is a mistake.`)] }).catch(()=>{});
        return;
      }
    }
  } catch (error) {
    console.error('Interaction error:', error);
    const message = 'Terjadi error saat menjalankan command. Periksa console dan permission bot.';
    if (interaction.isRepliable() && !interaction.replied && !interaction.deferred) await interaction.reply({ content: message, ephemeral: true }).catch(()=>{});
    else if (interaction.isRepliable() && interaction.deferred) await interaction.editReply({ content: message }).catch(()=>{});
  }
});
if (!process.env.BOT_TOKEN) { console.error('BOT_TOKEN belum diisi di .env'); process.exit(1); }
client.login(process.env.BOT_TOKEN);
