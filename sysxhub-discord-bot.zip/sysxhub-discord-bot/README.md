# SysxHub Discord Bot

Node.js + discord.js v14. Features: slash commands, moderation (`/to`, `/ban`), Lua source compaction (`/obf`), package purchase requests with QRIS image and owner Approve/Denied buttons, script catalogue (`/addscript`, `/scripts`, `/deletescript`), tickets, verification role, rules and welcome panels.

## Requirements
- Node.js 20+
- A Discord application and bot token from https://discord.com/developers/applications
- Bot invited with `bot` and `applications.commands` scopes and permissions to send messages, embed links, attach files, manage roles/channels, timeout members and ban members as needed.

## Setup
1. Extract the ZIP.
2. Run `npm install`.
3. Copy `.env.example` to `.env` and fill in `BOT_TOKEN`, `CLIENT_ID`, `GUILD_ID`, and (if used) `VERIFIED_ROLE_ID`.
4. In the Developer Portal, enable **Server Members Intent** if your bot needs welcome events.
5. Run `npm run deploy` to register slash commands in the configured test server.
6. Run `npm start`.

On startup, the bot tries to send panels to the supplied channel IDs. `/setup` can send them again if needed; existing recent panel messages are checked to avoid duplicates. The bot must be in the server containing those channels.

## Important limitations
- `/bypass` does not contain a magic Delta bypass. It only calls a real provider configured with `BYPASS_API_URL`; the endpoint must accept `POST` JSON `{ "url": "...", "discordUserId": "..." }` and return JSON containing a `key`, `deltaKey`, or `result` field. Configure an API key in `BYPASS_API_KEY` if your provider requires it. With no endpoint, the bot explicitly reports that bypass is not configured rather than fabricating a result.
- `/obf` compacts whitespace/comments only. It is not a secure or universal Lua obfuscator, and transformed code must be tested. It intentionally does not claim 100% compatibility.
- QRIS is static. The QR image encodes the supplied QRIS payload; buyer must transfer the requested amount manually. This bot cannot verify payment automatically. Owner approval is manual, and approval does not automatically issue a license key.
- `/key` and `/revokekey` are informational stubs; automated license issuance/validation/revocation needs a proper key system before production.
- Permanent and Lifetime prices are ranges in the request, so the bot asks buyers to contact the owner for the final price.
- `/addscript` uses a slash string option and therefore code input is limited by Discord's option length. For long scripts, a modal or file-upload workflow should be added.
- This project was generated as a starter and has not been tested with your Discord server, token, roles, or provider. Run `node --check index.js` and test in a private server first.
