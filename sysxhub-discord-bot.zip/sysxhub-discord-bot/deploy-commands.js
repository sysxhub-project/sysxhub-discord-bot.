require('dotenv').config();
const { REST, Routes, SlashCommandBuilder, PermissionFlagsBits } = require('discord.js');

const packages = [
  { name: 'Trial — 1 hari — Gratis', value: 'trial' },
  { name: 'Basic — 3 hari — Rp5.000', value: 'basic' },
  { name: 'Weekly — 7 hari — Rp10.000', value: 'weekly' },
  { name: 'Monthly — 30 hari — Rp20.000', value: 'monthly' },
  { name: 'Permanent — Rp35.000–50.000', value: 'permanent' },
  { name: 'Lifetime + Update — Rp75.000–100.000', value: 'lifetime' }
];
const cmds = [
  new SlashCommandBuilder().setName('help').setDescription('Daftar command SysxHub'),
  new SlashCommandBuilder().setName('ping').setDescription('Cek latency bot'),
  new SlashCommandBuilder().setName('setup').setDescription('Kirim panel otomatis SysxHub').setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
  new SlashCommandBuilder().setName('obf').setDescription('Compact kode Lua').addStringOption(o=>o.setName('kode').setDescription('Kode Lua (maks 12.000 karakter)').setRequired(true)),
  new SlashCommandBuilder().setName('to').setDescription('Timeout member').addUserOption(o=>o.setName('user').setDescription('Member target').setRequired(true)).addIntegerOption(o=>o.setName('menit').setDescription('Durasi timeout dalam menit').setRequired(true).setMinValue(1).setMaxValue(40320)).addStringOption(o=>o.setName('alasan').setDescription('Alasan timeout').setRequired(false)),
  new SlashCommandBuilder().setName('ban').setDescription('Ban member').addUserOption(o=>o.setName('user').setDescription('Member target').setRequired(true)).addStringOption(o=>o.setName('alasan').setDescription('Alasan ban').setRequired(false)),
  new SlashCommandBuilder().setName('bypass').setDescription('Proses bypass melalui provider yang dikonfigurasi').addStringOption(o=>o.setName('url').setDescription('URL/identifier yang didukung provider').setRequired(true)),
  new SlashCommandBuilder().setName('beli').setDescription('Tampilkan pilihan paket key'),
  new SlashCommandBuilder().setName('addscript').setDescription('Tambahkan script ke katalog').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild).addStringOption(o=>o.setName('nama').setDescription('Nama script').setRequired(true)).addStringOption(o=>o.setName('kategori').setDescription('Nama kategori').setRequired(true)).addStringOption(o=>o.setName('loadstring').setDescription('Kode Lua atau loadstring').setRequired(true)),
  new SlashCommandBuilder().setName('scripts').setDescription('Lihat script yang tersedia').addStringOption(o=>o.setName('kategori').setDescription('Filter kategori').setRequired(false)),
  new SlashCommandBuilder().setName('deletescript').setDescription('Hapus script dari katalog').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild).addStringOption(o=>o.setName('id').setDescription('ID script').setRequired(true)),
  new SlashCommandBuilder().setName('key').setDescription('Lihat petunjuk aktivasi key').addStringOption(o=>o.setName('key').setDescription('Key yang ingin dicek').setRequired(true)),
  new SlashCommandBuilder().setName('revokekey').setDescription('Cabut key (fitur penyimpanan key perlu diaktifkan)').setDefaultMemberPermissions(PermissionFlagsBits.Administrator).addStringOption(o=>o.setName('key').setDescription('Key yang dicabut').setRequired(true))
].map(c=>c.toJSON());

(async()=>{
  if (!process.env.BOT_TOKEN || !process.env.CLIENT_ID) throw new Error('Isi BOT_TOKEN dan CLIENT_ID di .env');
  const rest = new REST({ version: '10' }).setToken(process.env.BOT_TOKEN);
  const route = process.env.GUILD_ID
    ? Routes.applicationGuildCommands(process.env.CLIENT_ID, process.env.GUILD_ID)
    : Routes.applicationCommands(process.env.CLIENT_ID);
  await rest.put(route, { body: cmds });
  console.log(`Registered ${cmds.length} commands ${process.env.GUILD_ID ? 'to guild '+process.env.GUILD_ID : 'globally'}.`);
})().catch(e=>{ console.error(e); process.exit(1); });
